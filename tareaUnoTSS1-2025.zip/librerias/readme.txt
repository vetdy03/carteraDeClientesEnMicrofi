 Instrucciones de instalación:
Para instalar todas las librerías en un entorno nuevo, ejecuta:

pip install -r requirements.txt
